## Student Id: 1239302
## Student Name: Fangtai Dong

## running env
Need to be in the environment of Node JS to run the code.
Download from https://nodejs.org/en/download/

## foloder structure
1. node moudules --> for fetch module import
2. package.json --> for the javascript runnint confguration
3. getCookie.py --> for getting Cookie from the HOST and keep status of login

4. sqlInjection.js --> apply sql injection (bind) script.
5. sqlWildcardAttack.js --> apply wildcard attack.
6. ssrf.js --> apply server side request forgery attack.
7. xss.js --> apply cross site script attackt.

